import logicmy

if __name__ == "__main__":
    mat = logicmy.start_game()

while(True):
    key = input()
    if key.lower() == "w":
        mat, flag = logicmy.move_up(mat)
        status = logicmy.get_current_state(mat)
        print(status)

        if status == "GAME NOT OVER":
            logicmy.add_new_2(mat)
        else:
            break

    elif key.lower() == 's':
        mat, flag = logicmy.move_down(mat)
        status = logicmy.get_current_state(mat)
        print(status)

        if status == "GAME NOT OVER":
            logicmy.add_new_2(mat)
        else:
            break

    elif key.lower() == 'a':
        mat, flag = logicmy.move_left(mat)
        status = logicmy.get_current_state(mat)
        print(status)

        if status == "GAME NOT OVER":
            logicmy.add_new_2(mat)
        else:
            break

    elif key.lower() == 'd':
        mat, flag = logicmy.move_right(mat)
        status = logicmy.get_current_state(mat)
        print(status)

        if status == "GAME NOT OVER":
            logicmy.add_new_2(mat)
        else:
            break

    else:
        print("Invalid key pressed!")

    print("\n".join(map(str, mat)))



